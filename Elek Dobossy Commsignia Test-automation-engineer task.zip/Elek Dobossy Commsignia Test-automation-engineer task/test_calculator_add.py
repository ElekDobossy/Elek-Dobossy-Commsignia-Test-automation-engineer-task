import pytest
import calculator

@pytest.mark.parametrize("a,b,result", [
    (1, 2, 3),
    (0.5, 0.25, 0.75),
    (1,10000000,10000001),
    (100000.9,0.00000005,100000.90000005),
    (2,-6,(2 + -6)),
])
def test_calc_add_integer(a, b, result):
    calc = calculator.Calculator()
    assert calc.add(a, b) == result
