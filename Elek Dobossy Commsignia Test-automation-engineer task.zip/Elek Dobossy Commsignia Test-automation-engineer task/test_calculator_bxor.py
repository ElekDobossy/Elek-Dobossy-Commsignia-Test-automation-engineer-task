import pytest
import calculator

@pytest.mark.parametrize("a,b,result",[
    (1,1,0),
    (0,0,0),
    (1,0,1),
    (0,1,1),
    (0xFF,0x03,0xFC),
])
def test_calc_bxor_integer(a,b,result):
    calc=calculator.Calculator()
    assert calc.bxor(a,b) == result
