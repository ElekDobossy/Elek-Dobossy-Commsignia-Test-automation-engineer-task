import pytest
import calculator

@pytest.mark.parametrize("a,b,result",[
    (1,2,(1 % 2)),
    (5,3,(5 % 3)),
    (3,-1,(3 %-1)),
    (4,0.5,(4 % 0.5)),
    (4,4,(4 % 4)),
    (0.5,2,(0.5 % 2)),
])
def test_calc_rem_integer(a,b,result):
    calc=calculator.Calculator()
    assert calc.rem(a,b) == result

def test_calculator_rem_zero():
    calc = calculator.Calculator()
    with pytest.raises(ZeroDivisionError):
        calc.rem(1, 0)
