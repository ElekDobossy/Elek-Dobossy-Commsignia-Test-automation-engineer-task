import pytest
import calculator

@pytest.mark.parametrize("a,b,result", [
    (4, 2, (4 / 2)),
    (8, 5, (8 / 5)),
    (2, 4, (2 / 4)),
])
def test_calc_div_integer(a, b, result):
    calc = calculator.Calculator()
    assert calc.div(a, b) == result

def test_calculator_div_zero():
    calc = calculator.Calculator()
    with pytest.raises(ZeroDivisionError):
        calc.div(1, 0)
