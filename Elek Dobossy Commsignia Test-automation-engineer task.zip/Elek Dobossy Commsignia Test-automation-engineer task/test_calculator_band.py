import pytest
import calculator

@pytest.mark.parametrize("a,b,result",[
    (0x12,0xF0,0x10),
    (-1,1,1),
])
def test_calc_band_integer(a,b,result):
    calc=calculator.Calculator()
    assert calc.band(a,b) == result