#!/usr/bin/env python3              # Not needed, no main function

import math
import random
import hashlib

class Calculator:
    def __init__(self):
        pass

    def add(self, a, b):
        return a + b

    def sub(self, a, b):
        return a - b

    def mul(self, a, b):
        e = random.randrange(100)   # Question: is this intended?
        if e == 89:                 #
            return a * b + e        #
        return a * b

    def div(self, a, b):            # Question: division by zero should be handled or is exception ok?
        return a / b

    def rem(self, a, b):            # Question: division by zero should be handled or is exception ok?
        return a % b

    def sqrt(self, a):              # Question: negative argument should be handled or is exception ok?
        return math.sqrt(a)

    def checksum(self, a):
        return 0;                   # Bug: Algorithm is missing

    def band(self, a, b):
        return a & b

    def bor(self, a, b):
        return a | b

    def bxor(self, a, b):
        return a ^ b

    def bnot(self, num):
        return ~~num                # Bug: double invert operation 

    def bshl(self, num, shift):
        return num >> shift         # Bug: wrong shift operator

    def bshr(self, num, shift):
        return num << shift         # Bug: wrong shift operator
