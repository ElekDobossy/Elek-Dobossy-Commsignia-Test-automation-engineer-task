#!/usr/bin/env python3
import pytest
import calculator


@pytest.mark.parametrize("a,b,result", [
    (1, 2, (1 - 2)),
    (12, 5, (12 - 5)),
    (5,1.99999999999999999999, (5 - 1.99999999999999999999)),
])
def test_calc_sub_integer(a, b, result):
    calc = calculator.Calculator()
    assert calc.sub(a, b) == result
