import pytest
import calculator
import calculator_fixed

@pytest.mark.parametrize("a,b,result",[
    (1,2,(1 * 2)),
])
def test_calc_mul_integer(a,b,result):
    calc=calculator.Calculator()
    for i in range(1000):
        assert calc.mul(a,b,) == result     # This test fails randomly

@pytest.mark.parametrize("a,b,result",[
    (1,2,(1 * 2)),
])
def test_calc_mul_fixed_integer(a,b,result):
    calc=calculator_fixed.Calculator()
    for i in range(1000):
        assert calc.mul(a,b,) == result
