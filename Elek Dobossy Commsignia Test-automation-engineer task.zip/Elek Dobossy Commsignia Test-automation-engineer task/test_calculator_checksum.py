import pytest
import calculator
import calculator_fixed

@pytest.mark.parametrize("a,result",[
    (b"Test",'0cbc6611f5540bd0809a388dc95a615b') 
])
def test_calc_checksum_integer(a,result):
    calc=calculator.Calculator()
    assert calc.checksum(a) == result

@pytest.mark.parametrize("a,result",[
    (b"Test",'0cbc6611f5540bd0809a388dc95a615b') 
])
def test_calc_checksum_fixed_integer(a,result):
    calc=calculator_fixed.Calculator()
    assert calc.checksum(a) == result
