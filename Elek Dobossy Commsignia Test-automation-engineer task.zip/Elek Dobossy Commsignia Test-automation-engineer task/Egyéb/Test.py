import hashlib

a = b"Test"
md5sum = hashlib.md5(a).hexdigest()
print(md5sum)