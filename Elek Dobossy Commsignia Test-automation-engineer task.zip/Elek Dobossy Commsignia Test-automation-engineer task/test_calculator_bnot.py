import pytest
import calculator
import calculator_fixed

@pytest.mark.parametrize("num,result",[
    (1,~1),
    (0,~0),
    (0x65, ~0x65),
])
def test_calc_bnot_integer(num,result):
    calc=calculator.Calculator()
    assert calc.bnot(num) == result

@pytest.mark.parametrize("num,result",[
    (1,~1),
    (0,~0),
    (0x65, ~0x65),
])
def test_calc_bnot_fixed_integer(num,result):
    calc=calculator_fixed.Calculator()
    assert calc.bnot(num) == result