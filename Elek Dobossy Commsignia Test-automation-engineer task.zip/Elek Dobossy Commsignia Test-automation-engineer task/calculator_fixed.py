import math
import random
import hashlib

class Calculator:
    def __init__(self):
        pass

    def add(self, a, b):
        return a + b

    def sub(self, a, b):
        return a - b

    def mul(self, a, b):                    # Fixed: random part removed
        return a * b

    def div(self, a, b):
        return a / b

    def rem(self, a, b):
        return a % b

    def sqrt(self, a):
        return math.sqrt(a)

    def checksum(self, a):
        return hashlib.md5(a).hexdigest()   # Fixed: md5 is used to calculate checksum

    def band(self, a, b):
        return a & b

    def bor(self, a, b):
        return a | b

    def bxor(self, a, b):
        return a ^ b

    def bnot(self, num):
        return ~ num                         # Fixed: single invert operator

    def bshl(self, num, shift):
        return num << shift                 # Fixed: proper shift operator

    def bshr(self, num, shift):
        return num >> shift                 # Fixed: proper shift operator
