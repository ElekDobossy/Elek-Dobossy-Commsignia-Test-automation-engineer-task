import pytest
import calculator
import calculator_fixed

@pytest.mark.parametrize("num,shift,result",[
    (8,3,1),
    (0xFF00,4,0x0FF0),
    (-8,1,-4),
])
def test_calc_bshr_integer(num,shift,result):
    calc=calculator.Calculator()
    assert calc.bshr(num,shift) == result

@pytest.mark.parametrize("num,shift,result",[
    (8,3,1),
    (0xFF00,4,0x0FF0),
    (-8,1,-4),
])
def test_calc_bshr_fixed_integer(num,shift,result):
    calc=calculator_fixed.Calculator()
    assert calc.bshr(num,shift) == result
