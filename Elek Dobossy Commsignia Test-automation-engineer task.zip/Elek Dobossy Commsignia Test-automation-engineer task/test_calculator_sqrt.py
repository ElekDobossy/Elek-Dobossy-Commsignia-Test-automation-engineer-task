import pytest
import calculator

@pytest.mark.parametrize("a,result",[
    (9,3),
    (25,5)
])
def test_calc_sqrt_integer(a,result):
    calc=calculator.Calculator()
    assert calc.sqrt(a) == result

def test_calculator_sqrt_zero():
    calc = calculator.Calculator()
    with pytest.raises(ValueError):
        calc.sqrt(-8)
