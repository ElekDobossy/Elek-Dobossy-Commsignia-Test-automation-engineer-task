import pytest
import calculator

@pytest.mark.parametrize("a,b,result",[
    (1,1,1),
    (0,1,1),
    (1,0,1),
    (0,0,0),
    (0x0F,0xF0,0xFF),
])
def test_calc_bor_integer(a,b,result):
    calc=calculator.Calculator()
    assert calc.bor(a,b) == result
