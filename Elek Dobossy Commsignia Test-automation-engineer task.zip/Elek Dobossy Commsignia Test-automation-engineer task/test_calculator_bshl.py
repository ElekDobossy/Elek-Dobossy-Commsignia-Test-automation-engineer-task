import pytest
import calculator
import calculator_fixed

@pytest.mark.parametrize("num,shift,result",[
    (1,3,8),                # shifting decimal number
    (0x00FF,8,0xFF00),      # shifting hexadecimal number 
    (-8,1,-16),             # check sign bit shifting
])
def test_calc_bshl_integer(num,shift,result):
    calc=calculator.Calculator()
    assert calc.bshl(num,shift) == result

@pytest.mark.parametrize("num,shift,result",[
    (1,3,8),
    (0x00FF,8,0xFF00),
    (-8,1,-16),
])
def test_calc_bshl_fixed_integer(num,shift,result):
    calc_fixed=calculator_fixed.Calculator()
    assert calc_fixed.bshl(num,shift) == result
